﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class StartUp
{
    static void Main(string[] args)
    {
        Car car = new Car();
        var numberOfCars = int.Parse(Console.ReadLine());

        for (int i = 0; i < numberOfCars; i++)
        {
            var carInfo = Console.ReadLine().Split(' ');

            var model = carInfo[0].ToString();
            var fuelAmount = double.Parse(carInfo[1]);
            var FuelConsumptionFor1km = double.Parse(carInfo[2]);
            Car currentCar = new Car
            {
                Model = model,
                FuelAmount = fuelAmount,
                FuelConsumptionFor1Km = FuelConsumptionFor1km
            };

            car.AddCar(currentCar);
        }

        var command = Console.ReadLine().Split(' ');
        while (!command.Contains("End"))
        {
            var driveModel = command[1];
            var driveKm = double.Parse(command[2]);

            car.CanMoveThatDistance(driveModel, driveKm);

            command = Console.ReadLine().Split(' ');
        }

        car.PrintCars();
    }
}
